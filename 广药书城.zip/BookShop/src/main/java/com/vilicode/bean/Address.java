package com.vilicode.bean;

public class Address {
    private Integer aid;
    private Integer uid;
    private String aphone;
    private String aaddr;
    public Integer getAid() {
        return aid;
    }

    public void setAid(Integer aid) {
        this.aid = aid;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getAphone() {
        return aphone;
    }

    public void setAphone(String aphone) {
        this.aphone = aphone;
    }

    public String getAaddr() {
        return aaddr;
    }

    public void setAaddr(String aaddr) {
        this.aaddr = aaddr;
    }
}
